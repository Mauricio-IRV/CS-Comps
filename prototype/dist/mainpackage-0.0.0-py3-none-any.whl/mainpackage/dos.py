from scapy.all import Ether, TCP, Raw, sendp
from networking import *

def dos(packet):
    print("")